public class MasterIP {

    private String sourceIP;
    private String destIP;
    private Integer IPLength;
    private String fileName;
    private String timeStamp;

    public void setSourceIP(String sourceIP) {
        this.sourceIP = sourceIP;
    }
    public void setDestIP(String destIP) {
        this.destIP = destIP;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }


    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public void setIPLength(Integer IPLength) {
        this.IPLength = IPLength;
    }

    public String getSourceIP() {
        return sourceIP;
    }

    public String getDestIP() {
        return destIP;
    }

    public Integer getIPLength() {
        return IPLength;
    }

    public String getFileName() {
        return fileName;
    }

    public String getTimeStamp() {
        return timeStamp;
    }
}
