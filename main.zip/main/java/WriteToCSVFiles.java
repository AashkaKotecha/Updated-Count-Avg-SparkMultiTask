
import org.apache.spark.sql.SparkSession;
import org.beanio.BeanWriter;
import org.beanio.StreamFactory;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class WriteToCSVFiles {
    static String csvFolder = Constants.properties.getProperty("csvFolder");
    //static String csvFolder = "D:/TestProp/CSV/";
    static String end = ".csv";
    static String csvFileName;
    static String csvSubFolderName;

    public static void createSourceCSVFromPcap(List<MultipleValues> holdList, String filename, SparkSession sparkSession,String serverName) {
        csvSubFolderName= "CSV-"+serverName;
        File subFolder = new File(csvFolder+csvSubFolderName);
        if(!(subFolder.mkdir()))
            subFolder.mkdir();

        csvFileName = csvFolder + csvSubFolderName+"/" +filename + end;
        long startTime =System.currentTimeMillis();
        try {
            File file = new File(csvFileName);
            boolean flag = false;

            flag = file.createNewFile();

            System.out.println("File creation: " + flag);

            StreamFactory streamFactory = StreamFactory.newInstance();
            streamFactory.loadResource("MasterIP.xml");
            BeanWriter beanWriter = streamFactory.createWriter("streamMasterIP", new File(csvFileName));
            MasterIP mipWrite = new MasterIP();

            for (MultipleValues multipleValues : holdList) {
                mipWrite.setSourceIP(multipleValues.getSourceIP());
                mipWrite.setDestIP(multipleValues.getDestIP());
                mipWrite.setIPLength(multipleValues.getDataLength());
                mipWrite.setFileName(multipleValues.getFileName());
                mipWrite.setTimeStamp(multipleValues.getTimeStamp());
                beanWriter.write(mipWrite);
            }
            beanWriter.flush();
            beanWriter.close();

            long endTime =System.currentTimeMillis();
            long diffTime = endTime-startTime;
            System.out.println("Time taken for CSV generation: "+diffTime);

            NewSparkConfigClass.sparkConversion(csvFileName,sparkSession,serverName);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
