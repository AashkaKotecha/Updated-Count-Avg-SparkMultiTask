
import org.apache.spark.SparkContext;
import org.apache.spark.sql.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.apache.spark.api.java.StorageLevels.MEMORY_ONLY;

public class NewSparkConfigClass {
    private static final String CSV_MASTER=Constants.properties.getProperty("masterIP");
    //private static final String CSV_MASTER="D:/TestProp/Master.csv";

    public static void sparkConversion(String csvFileName, SparkSession sparkSession,String serverName) {
/*
        if(sparkSession.sparkContext().isStopped()){
            sparkSession.newSession();
        }*/
        final String folderName, subFolderName;
        final String CSV_WANCAP=csvFileName;
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date();

        long startTime =System.currentTimeMillis();


        Dataset<Row> df_master = sparkSession.read().format("csv")
                .option("header","false")
                .load(CSV_MASTER)
                .toDF("IP")
                .persist(MEMORY_ONLY);


        Dataset<Row> df_wancap = sparkSession.read().format("csv")
                .option("header","false")
                .load(CSV_WANCAP)
                .toDF("srcIP","destIP","datalength","filename","timestamp");

        Dataset<Row> sourceIP = df_wancap.join(df_master,df_wancap.col("srcIP").equalTo(df_master.col("IP")),"left_anti");

        Dataset<Row> destIP = df_wancap.join(df_master,df_wancap.col("destIP").equalTo(df_master.col("IP")),"left_anti");

       /* Dataset<Row> finalOutputdf = df_wancap.select("srcIP","datalength","filename","timestamp")
                .coalesce(1)
                .join(df_master,df_master.col("srcIP")
                        .equalTo(df_wancap.col("srcIP")), "left_anti");*/

        Dataset<Row> finalOutputdf =sourceIP.union(destIP);

        //Creating date-wise folder to hold the output
        folderName = "Output-"+formatter.format(date);
        subFolderName = "Output-"+serverName;
        File folder = new File(Constants.properties.getProperty("outputFolderPath")+folderName);
       // File folder = new File("D:/TestProp/Output/"+folderName);
        if(!(folder.mkdir())){
            folder.mkdir();
        }
        File subFolder = new File(Constants.properties.getProperty("outputFolderPath")+folderName+"/"+subFolderName);
        //File subFolder = new File("D:/TestProp/Output/"+folderName+"/"+subFolderName);
        if(!(subFolder.mkdir())){
            subFolder.mkdir();
        }
        /*String fileName = folder.getAbsolutePath()+"\\"
                +System.getProperty("outputCSVInvalidFilePath")+"_"+sourceCSV+System.getProperty("csvEnd");

        System.out.println("Output file to be created with name : "+fileName);*/

       /* DariaWriters.writeSingleFile(finalOutputdf,
                "csv",
                sparkContext,
                "D:/Tableu/",
                fileName,
                "append");*/
        finalOutputdf.coalesce(1).select("srcIP","destIP","datalength","filename","timestamp").distinct().write().mode("append").option("header",true).csv(subFolder.getAbsolutePath());
        System.out.println("Output file generated!!!!");


        long endTime =System.currentTimeMillis();
        long diffTime = endTime-startTime;
        System.out.println("Time taken by Spark Class: "+diffTime);

    }


}
