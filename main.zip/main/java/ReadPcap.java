
import java.io.File;
import java.nio.BufferUnderflowException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.spark.sql.SparkSession;
import org.jnetpcap.Pcap;
import org.jnetpcap.packet.JPacketHandler;
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;


public class ReadPcap {

    static String folderPath = Constants.properties.getProperty("folderPath");
    //static String folderPath = "D:/TestProp/Extracted/";
    private static int IPTotalLength;

    public static void readPcap( String pcapFileName, SparkSession sparkSession, String serverName) {
        long startTime =System.currentTimeMillis();
        String pcapFilePath = folderPath +serverName+"/"+ pcapFileName;
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yy HH:mm:ss");
        Date date = new Date();
        List<MultipleValues> holdIPList = new ArrayList<MultipleValues>();
        StringBuilder errbuf = new StringBuilder();
        try {
            System.out.println("Reading pcap file : " + pcapFilePath);
            final Pcap pcap = Pcap.openOffline(pcapFilePath, errbuf);

            if (pcap == null) {
                System.out.println("Error occurred : " + errbuf);
                return;
            }
            //new JPacketHandler<String>()
            pcap.loop(-1, (JPacketHandler<String>) (jPacket, s) -> {
                try {
                    String sourceIP, destinationIP;
                    Ip4 ip = new Ip4();
                    final Tcp tcp = new Tcp();
                    if (jPacket.hasHeader(tcp) || jPacket.hasHeader(ip)) {

                        //Fetching info from each packet
                        sourceIP = FormatUtils.ip(ip.source());
                        destinationIP = FormatUtils.ip(ip.destination());
                        IPTotalLength = ip.getLength() + ip.getPayloadLength();

                        //Setting all values corresponding to each IP
                        MultipleValues mvSource = new MultipleValues(sourceIP,destinationIP,pcapFileName,IPTotalLength,formatter.format(date));
                        //MultipleValues mvDestination = new MultipleValues(destinationIP,pcapFileName,IPTotalLength,formatter.format(date));

                        //Putting the object containing all the info of sourceIP and destinationIP into a single List
                        holdIPList.add(mvSource);
                      //  holdIPList.add(mvDestination);




                    }
                } catch (BufferUnderflowException | IndexOutOfBoundsException | NullPointerException e) {
                    e.getMessage();
                }
            }, "jNetPcap");

            //Pushing the List containing all the info of sourceIP and destinationIP into a single sourceCSV file
            System.out.println("Now creating csv file from pcap file: "+pcapFileName);
            WriteToCSVFiles.createSourceCSVFromPcap( holdIPList, pcapFileName,sparkSession,serverName);
            pcap.close();
            long endTime =System.currentTimeMillis();
            long diffTime = endTime-startTime;
            System.out.println("Time taken to create CSV file is approx: "+diffTime);


        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error while reading file: " + e.getMessage());
        }
    }


}
