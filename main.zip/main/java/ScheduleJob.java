import org.apache.commons.io.FileUtils;
import org.apache.spark.sql.SparkSession;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class Wancap implements Runnable{
    private final String fileName;

    Wancap(String fileName){
        this.fileName=fileName;
    }
    @Override
    public void run() {
        ScheduleJob.insideRun(fileName);
    }
}

class Omxcap implements Runnable{
    private final String fileName;

    Omxcap(String fileName){
        this.fileName=fileName;
    }
    @Override
    public void run() {
        ScheduleJob.insideRun(fileName);
    }
}

class Omscap implements Runnable{
    private final String fileName;
    Omscap(String fileName){
        this.fileName=fileName;
    }
    @Override
    public void run() {
        ScheduleJob.insideRun(fileName);
    }
}

class Gwcap implements Runnable {
    private final String fileName;

    Gwcap(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void run() {
        ScheduleJob.insideRun(fileName);
    }
}

class Oms3cap implements Runnable{
    private final String fileName;

    Oms3cap(String fileName){
        this.fileName=fileName;
    }
    @Override
    public void run() {
        ScheduleJob.insideRun(fileName);
    }
}

public class ScheduleJob {
    public static void main(String[] args)
    {


        ScheduledExecutorService executor1 = Executors.newScheduledThreadPool(1);
        Wancap wancap = new Wancap("wancap");
        executor1.scheduleAtFixedRate(wancap, 0,60, TimeUnit.SECONDS);
        ScheduledExecutorService executor2 = Executors.newScheduledThreadPool(1);
        Omxcap omxcap = new Omxcap("omxcap");
        executor2.scheduleAtFixedRate(omxcap,0,60, TimeUnit.SECONDS);
        ScheduledExecutorService executor3 = Executors.newScheduledThreadPool(1);
        Omscap omscap = new Omscap("omscap");
        executor3.scheduleAtFixedRate(omscap,0,60, TimeUnit.SECONDS);
        Gwcap gwcap = new Gwcap("gwcap");
        ScheduledExecutorService executor4 = Executors.newScheduledThreadPool(1);
        executor4.scheduleAtFixedRate(gwcap,0,60, TimeUnit.SECONDS);
        ScheduledExecutorService executor5 = Executors.newScheduledThreadPool(1);
        Oms3cap oms3cap = new Oms3cap("oms3cap");
        executor5.scheduleAtFixedRate(oms3cap,0,60, TimeUnit.SECONDS);

    }

    public static void insideRun(String folderName) {
        SparkSession sparkSession = SparkSession.builder().master("local[*]").getOrCreate();

        System.out.println("Current folder inside Extracted folder: "+folderName);
        String folderToBeReadPath =Constants.properties.getProperty("folderPath")+folderName+"/";
        // folderToBeReadPath ="D:/TestProp/Extracted/"+folderName+"/";
        File folderToBeRead = new File(folderToBeReadPath);
        if(folderToBeRead.exists() && folderToBeRead.listFiles().length>0){
            File contents[] = folderToBeRead.listFiles();
            for(File file : contents){
                String filePath = file.getAbsolutePath();
                String fileExtension = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length());
                if(fileExtension.contains("pcap")){
                    System.out.println("Reading file : "+file.getName());
                    ReadPcap.readPcap(file.getName(),sparkSession,folderName);
                    try {
                        FileUtils.forceDelete(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //file.delete();
                    System.out.println("Pcap file "+file+" is now deleted !!");

                }
            }

        }
    }
}
