public class MultipleValues {
    String sourceIP;
    String destIP;
    String fileName;
    Integer dataLength;
    String timeStamp;

    public MultipleValues(String sourceIP,String destIP, String fileName, Integer dataLength, String timeStamp) {
        this.sourceIP = sourceIP;
        this.destIP = destIP;
        this.fileName = fileName;
        this.dataLength = dataLength;
        this.timeStamp = timeStamp;
    }


    public String getSourceIP() {
        return sourceIP;
    }

    public String getDestIP() {
        return destIP;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public String getFileName() {
        return fileName;
    }


    public Integer getDataLength() {
        return dataLength;
    }

}
